A Pen created at CodePen.io. You can find this one at http://codepen.io/mspanish/pen/JYexvd.

 Tutorial from Design Shack 
http://designshack.net/articles/css/5-simple-and-practical-css-list-styles-you-can-copy-and-paste/

Forked from [yying6](http://codepen.io/yying6/)'s Pen [Standard Thumbnail Grid](http://codepen.io/yying6/pen/gBunD/).